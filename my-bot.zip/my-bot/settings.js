
const fs = require("fs");
const chalk = require("chalk")

global.BOT_TOKEN = "8670511704:AAH-EWsglAeAHgyF1Vi5-Q7GWTg4SWcTjGY" // create bot here https://t.me/Botfather and get bot token
global.BOT_NAME = "- 𝑰𝑻𝑺 »ṦℋĄ₦ŜℍẨᴎ  CRASH BOT»࿅ 𓈪" //your bot name
global.OWNER_NAME = "https://t.me/ibraheembaython" //your name with sign @
global.OWNER = ["https://t.me/ibraheembaython", "https://t.me/ibraheembaython"] // Make sure the username is correct so that the special owner features can be used.
global.DEVELOPER = ["5904531543"] //developer telegram id to operate addprem delprem and listprem
global.pp = 'https://files.catbox.moe/8drb6g.jpg' //your bot pp


//approval
global.GROUP_ID = -1004398943021; // Replace with your group ID
global.CHANNEL_ID =  -1002929484403; // Replace with your channel ID
global.GROUP_LINK = "https://t.me/+QcQonTs2WWlmNDdk"; // Replace with your group link
global.CHANNEL_INVITE_LINK = "https://t.me/alwshahh"; // Replace with your private channel invite link
global.WHATSAPP_LINK = "https://wa.me/201514142074"; // Replace with your group link
global.YOUTUBE_LINK = "https://www.youtube.com/@shanshanalnjm"; // Replace with your youtube link
global.INSTAGRAM_LINK = "https://www.instagram.com/i.0.v0?stkn=eWhuc202Ym9jcGpj"; // Replace with your ig link

global.owner = global.owner = ['+967770604206'] //owner whatsapp

const {
   english
} = require("./lib");
global.language = english
global.lang = language

let file = require.resolve(__filename)
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(chalk.redBright(`Update ${__filename}`))
delete require.cache[file]
require(file)
})