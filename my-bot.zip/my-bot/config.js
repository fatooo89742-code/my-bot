

//contact details
global.ownernomer = "967770604206"
global.dev = ["967770604206","967770604206"]
global.ownername = "₷ℋầ₦Ꭶℍạⲛ Ảℒℕⅉᵯ"
global.ytname = "₷ℋầ₦Ꭶℍạⲛ Ảℒℕⅉᵯ"
global.socialm = "GitHub: ₷ℋầ₦Ꭶℍạⲛ Ảℒℕⅉᵯ"
global.location = "Egypt, cairo, shopra"

global.ownernumber = '967770604206'  //creator number
global.ownername = '₷ℋầ₦Ꭶℍạⲛ Ảℒℕⅉᵯ' //owner name
global.botname = 'Bot Crash  𝐕9 🌴' //name of the bot

//sticker details
global.packname = '\n\n\n\n\n\n\nSticker By'
global.author = '₷ℋầ₦Ꭶℍạⲛ Ảℒℕⅉᵯ ⚉\n\nContact: 967770604206'

//console view/theme
global.themeemoji = '🪀'
global.wm = "₷ℋầ₦Ꭶℍạⲛ Ảℒℕⅉᵯ."

//theme link
global.link = 'https://t.me/ibraheembaython'
global.idch = '0029VbE3HPg4NVibGIChcw2D@newsletter'

global.baileysDB = 'baileysDB.json'
global.botDb = 'database.json'

//prefix
global.prefa = ['','!','.',',','🐤','🗿'] 

global.limitawal = {
    premium: "Infinity",
    free: 20
}

//menu type 
//v1 is image menu, 
//v2 is link + image menu,
//v3 is video menu,
//v4 is call end menu
global.typemenu = 'v1'

// Global Respon
global.mess = {
    success: 'Done✓',
    admin: `\`[ # ]\` This Command Can Only Be Used By Group Admins !`,
    botAdmin: `\`[ # ]\` This Command Can Only Be Used When Bot Becomes Group Admin !`,
    OnlyOwner: `\`[ # ]\` This Command Can Only Be Used By Premium User ! \n\nWant Premium? Chat Developer.\nTelegram: @VIP_X1B\nWhatsApp: +2967770604206`,
    OnlyGrup: `\`[ # ]\` This Command Can Only Be Used In Group Chat !`,
    private: `\`[ # ]\` This Command Can Only Be Used In Private Chat !`,
    wait: `\`[ # ]\` Wait Wait a minute`,
    notregist: `\`[ # ]\` You are not registered in the Bot Database. Please register first.`,
    premium: `\`[ # ]\` This Command Can Only Be Used By Premium User ! \n\nWant Premium? Chat Developer.\nYouTube: @VIP_X1B\nTelegram:@VIP_X1B \nWhatsApp: +2967770604206`,
}

// ملف config.js
module.exports = {
    banner: [
        "967770604206@s.whatsapp.net",
        "20@s.whatsapp.net",
        "967770604206@s.whatsapp.net",
        "20@s.whatsapp.net",
        "20@s.whatsapp.net",
        "20@s.whatsapp.net"
    ]
};

let fs = require('fs')
let file = require.resolve(__filename)
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(`Update ${__filename}`)
delete require.cache[file]
require(file)
})